package Interface;

public interface Negociavel {
    void negociar();
}
